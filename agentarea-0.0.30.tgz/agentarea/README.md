# agentarea

> AgentArea is an AI agent platform. This chart deploys the API, frontend, worker, MCP Manager, and optional dependencies.

## Usage

```bash
helm repo add agentarea https://agentarea.github.io/helm-charts
helm repo update
helm install agentarea agentarea/agentarea \
  --namespace agentarea --create-namespace
```

## Prerequisites

- Kubernetes 1.20+
- Helm 3.8+
- PV provisioner for PostgreSQL/RustFS persistence (if enabled)

## Installing with external services

If you have existing PostgreSQL, Redis or S3-compatible storage, disable bundled dependencies and set endpoints:

```yaml
postgresql:
  enabled: false
redis:
  enabled: false
rustfs:
  enabled: false

global:
  database:
    host: "db.example.com"
    port: 5432
    name: "agentarea"
  redis:
    host: "redis.example.com"
    port: 6379
  storage:
    type: "s3"
    endpoint: "https://s3.amazonaws.com"
    bucket: "agentarea-docs"
    region: "us-east-1"
```

## Parameters

The following table lists configurable parameters of the chart and their default values.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| serviceAccount.create | bool | `true` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.name | string | `"agentarea"` |  |
| nameOverride | string | `""` |  |
| fullnameOverride | string | `""` |  |
| global.edition | string | `"community"` |  |
| global.version | string | `"0.0.3"` |  |
| global.cluster.type | string | `"kubernetes"` |  |
| global.cluster.name | string | `"agentarea"` |  |
| global.deploymentEnv | string | `"production"` |  |
| global.image.pullPolicy | string | `"IfNotPresent"` |  |
| global.image.registry | string | `""` |  |
| global.image.pullSecrets | list | `[]` |  |
| global.serviceAccountName | string | `"agentarea"` |  |
| global.secrets.postgresql | string | `"agentarea-postgresql-secret"` |  |
| global.secrets.redis | string | `"agentarea-redis-secret"` |  |
| global.secrets.rustfs | string | `"agentarea-rustfs-secret"` |  |
| global.secrets.application | string | `"agentarea-app-secrets"` |  |
| global.secrets.applicationExistingSecret | bool | `false` |  |
| global.runtimeCredentials.existingSecret | string | `"agentarea-runtime-credentials"` |  |
| global.runtimeCredentials.keys.mcpGateway | string | `"mcp-gateway-token"` |  |
| global.runtimeCredentials.keys.sandboxFile | string | `"sandbox-file-token"` |  |
| global.runtimeCredentials.keys.sandboxInspection | string | `"sandbox-inspection-token"` |  |
| global.runtimeCredentials.keys.sandboxCleanup | string | `"sandbox-cleanup-token"` |  |
| global.mcpOAuthApps.existingSecret | string | `""` |  |
| global.mcpOAuthApps.existingSecretKey | string | `"mcp-oauth-apps"` |  |
| global.database.secretName | string | `"agentarea-postgresql-secret"` |  |
| global.database.host | string | `""` |  |
| global.database.port | int | `5432` |  |
| global.database.name | string | `"agentarea"` |  |
| global.database.ssl | bool | `false` |  |
| global.database.sslMode | string | `"disable"` |  |
| global.database.tenantScope | string | `"log"` | AGENTAREA_DB_TENANT_SCOPE: what an ORM query on a workspace-scoped table does when no workspace is bound. "log" runs it unfiltered and warns once per call site; "enforce" refuses it. Ship "log", clear the warnings, then flip. |
| global.database.maxConnections | int | `100` |  |
| global.database.connectionTimeout | string | `"30s"` |  |
| global.database.migrations.runAtStartup | bool | `true` |  |
| global.database.migrations.initializationTimeout | string | `"300s"` |  |
| global.database.migrations.command | list | `["agentarea-api","migrate"]` | Command the migration job runs in the API image, from /app/apps/api. An installed extension can name its own command, which must also run the core migrations. |
| global.redis.host | string | `""` |  |
| global.redis.port | int | `6379` |  |
| global.redis.url | string | `""` |  |
| global.redis.existingSecret | string | `""` |  |
| global.redis.existingSecretKey | string | `"url"` |  |
| global.redis.database | int | `0` |  |
| global.redis.ssl | bool | `false` |  |
| global.redis.maxConnections | int | `50` |  |
| global.redis.connectionTimeout | string | `"5s"` |  |
| global.events.namespace | string | `"agentarea"` |  |
| global.events.partitions | int | `16` |  |
| global.storage.type | string | `"rustfs"` |  |
| global.storage.endpoint | string | `""` |  |
| global.storage.publicEndpoint | string | `""` |  |
| global.storage.bucket | string | `"agentarea-documents"` |  |
| global.storage.region | string | `"us-east-1"` |  |
| global.storage.s3.accessKeyId | string | `""` |  |
| global.storage.s3.secretAccessKey | string | `""` |  |
| global.storage.s3.sessionToken | string | `""` |  |
| global.storage.gcs.projectId | string | `""` |  |
| global.storage.gcs.credentials | string | `""` |  |
| global.storage.rustfs.accessKey | string | `""` |  |
| global.storage.rustfs.secretKey | string | `""` |  |
| global.storage.cors.allowedOrigins | list | `[]` |  |
| global.temporal.host | string | `""` |  |
| global.temporal.port | int | `7233` |  |
| global.temporal.namespace | string | `"default"` |  |
| global.temporal.taskQueue | string | `"agent-tasks"` |  |
| global.temporal.client.connectionTimeout | string | `"10s"` |  |
| global.temporal.client.rpcTimeout | string | `"10s"` |  |
| global.temporal.client.longPollTimeout | string | `"60s"` |  |
| global.temporal.worker.maxConcurrentActivityExecutions | int | `10` |  |
| global.temporal.worker.maxConcurrentWorkflowTaskExecutions | int | `5` |  |
| global.temporal.worker.maxConcurrentSessionExecutions | int | `1000` |  |
| global.api.host | string | `"0.0.0.0"` |  |
| global.api.port | int | `8000` |  |
| global.api.publicUrl | string | `""` |  |
| global.api.auth.enabled | bool | `false` |  |
| global.api.auth.headerName | string | `""` |  |
| global.api.auth.headerValue | string | `""` |  |
| global.webapp.url | string | `""` |  |
| global.webapp.appsSandboxUrl | string | `""` |  |
| global.jobs.kube.namespace | string | `""` |  |
| global.jobs.kube.serviceAccount | string | `""` |  |
| global.jobs.kube.scheduling.spec.nodeSelectors | object | `{}` |  |
| global.jobs.kube.scheduling.check.nodeSelectors | object | `{}` |  |
| global.jobs.kube.scheduling.discover.nodeSelectors | object | `{}` |  |
| global.jobs.kube.resources.limits.cpu | string | `"1000m"` |  |
| global.jobs.kube.resources.limits.memory | string | `"1Gi"` |  |
| global.jobs.kube.resources.requests.cpu | string | `"500m"` |  |
| global.jobs.kube.resources.requests.memory | string | `"512Mi"` |  |
| global.jobs.kube.timeouts.spec | string | `"300s"` |  |
| global.jobs.kube.timeouts.check | string | `"600s"` |  |
| global.jobs.kube.timeouts.discover | string | `"900s"` |  |
| global.jobs.kube.mainContainerImagePullPolicy | string | `"IfNotPresent"` |  |
| global.jobs.kube.sidecarContainerImagePullPolicy | string | `"IfNotPresent"` |  |
| global.jobs.kube.images.busybox | string | `"busybox:1.38.0"` |  |
| global.workloads.resources.mainContainer.cpu.request | string | `"50m"` |  |
| global.workloads.resources.mainContainer.cpu.limit | string | `"1000m"` |  |
| global.workloads.resources.mainContainer.memory.request | string | `"128Mi"` |  |
| global.workloads.resources.mainContainer.memory.limit | string | `"1Gi"` |  |
| global.workloads.resources.sidecarContainer.cpu.request | string | `"10m"` |  |
| global.workloads.resources.sidecarContainer.cpu.limit | string | `"200m"` |  |
| global.workloads.resources.sidecarContainer.memory.request | string | `"64Mi"` |  |
| global.workloads.resources.sidecarContainer.memory.limit | string | `"256Mi"` |  |
| global.serviceMesh.enabled | bool | `false` |  |
| global.serviceMesh.type | string | `"istio"` |  |
| global.monitoring.prometheus.enabled | bool | `true` |  |
| global.monitoring.prometheus.port | int | `9090` |  |
| global.monitoring.prometheus.path | string | `"/metrics"` |  |
| global.monitoring.health.enabled | bool | `true` |  |
| global.monitoring.health.port | int | `8001` |  |
| global.monitoring.health.path | string | `"/health"` |  |
| global.analytics.enabled | bool | `true` | Send AgentArea anonymous usage statistics from the backend and worker: a daily count of agents, runs and connectors, never names, prompts, output or secrets. Not OpenTelemetry. false sends nothing. Field list: https://docs.agentarea.ai/self-host/analytics |
| global.http.extraCaCerts | string | `""` | PEM text of CA certificates to trust on outbound TLS in addition to the public roots, for hosts whose chain those roots leave out (the Russian Trusted Root CA, a corporate CA). Rendered into a ConfigMap, mounted into the backend and worker, and named by AGENTAREA_HTTP_EXTRA_CA_CERTS. Empty: public roots only. |
| global.security.podSecurityContext.fsGroup | int | `1000` |  |
| global.security.podSecurityContext.runAsUser | int | `1000` |  |
| global.security.podSecurityContext.runAsNonRoot | bool | `true` |  |
| global.security.containerSecurityContext.allowPrivilegeEscalation | bool | `false` |  |
| global.security.containerSecurityContext.readOnlyRootFilesystem | bool | `true` |  |
| global.security.containerSecurityContext.runAsNonRoot | bool | `true` |  |
| global.security.containerSecurityContext.capabilities.drop[0] | string | `"ALL"` |  |
| global.extraLabels | object | `{}` |  |
| global.extraSelectorLabels | object | `{}` |  |
| ingress.enabled | bool | `false` |  |
| ingress.className | string | `""` |  |
| ingress.annotations | object | `{}` |  |
| ingress.hosts.frontend.host | string | `""` |  |
| ingress.hosts.frontend.paths[0].path | string | `"/"` |  |
| ingress.hosts.frontend.paths[0].pathType | string | `"Prefix"` |  |
| ingress.hosts.backend.host | string | `""` |  |
| ingress.hosts.backend.paths[0].path | string | `"/"` |  |
| ingress.hosts.backend.paths[0].pathType | string | `"Prefix"` |  |
| ingress.hosts.kratos.host | string | `""` |  |
| ingress.hosts.kratos.paths[0].path | string | `"/"` |  |
| ingress.hosts.kratos.paths[0].pathType | string | `"Prefix"` |  |
| ingress.hosts.rustfs.host | string | `""` |  |
| ingress.hosts.rustfs.paths[0].path | string | `"/"` |  |
| ingress.hosts.rustfs.paths[0].pathType | string | `"Prefix"` |  |
| ingress.hosts.appsSandbox.host | string | `""` |  |
| ingress.hosts.appsSandbox.paths[0].path | string | `"/app-sandbox"` |  |
| ingress.hosts.appsSandbox.paths[0].pathType | string | `"Exact"` |  |
| ingress.tls | list | `[]` |  |
| backend.enabled | bool | `true` |  |
| backend.replicaCount | int | `1` |  |
| backend.workers | int | `1` | Uvicorn worker processes per pod. One process is one event loop, so one pod serves about one CPU core's worth of Python however large its CPU limit is. Prefer replicas over workers -- a pool inside the pod hides a stuck worker from the probes, which poll the pod, not the process. Raise this only when a deliberately larger CPU limit would otherwise go unused. |
| backend.preStopDelay | int | `5` | Seconds the pod keeps serving after it is marked for deletion, covering the gap before its removal from the Service endpoints has propagated. |
| backend.shutdownTimeout | int | `20` | Seconds uvicorn then waits for open connections to finish. Must be finite: the API serves SSE, and those connections never close on their own. |
| backend.terminationGracePeriodSeconds | int | `30` | Total budget the kubelet allows for the two above before SIGKILL. Keep it above preStopDelay + shutdownTimeout, or draining is cut short. |
| backend.image.repository | string | `"agentarea/agentarea-api"` |  |
| backend.image.tag | string | `""` |  |
| backend.image.pullPolicy | string | `""` |  |
| backend.service.type | string | `"ClusterIP"` |  |
| backend.service.port | int | `8000` |  |
| backend.service.annotations | object | `{}` |  |
| backend.service.labels | object | `{}` |  |
| backend.resources | object | `{}` |  |
| backend.livenessProbe.enabled | bool | `true` |  |
| backend.livenessProbe.initialDelaySeconds | int | `60` |  |
| backend.livenessProbe.periodSeconds | int | `30` |  |
| backend.livenessProbe.timeoutSeconds | int | `10` |  |
| backend.livenessProbe.failureThreshold | int | `3` |  |
| backend.readinessProbe.enabled | bool | `true` |  |
| backend.readinessProbe.initialDelaySeconds | int | `30` |  |
| backend.readinessProbe.periodSeconds | int | `10` |  |
| backend.readinessProbe.timeoutSeconds | int | `5` |  |
| backend.readinessProbe.failureThreshold | int | `3` |  |
| backend.nodeSelector | object | `{}` |  |
| backend.tolerations | list | `[]` |  |
| backend.affinity | object | `{}` |  |
| backend.podAnnotations | object | `{}` |  |
| backend.podLabels | object | `{}` |  |
| backend.extraEnvFrom | list | `[]` |  |
| backend.extraInitContainers | list | `[]` |  |
| backend.podSecurityContext | object | `{}` |  |
| backend.containerSecurityContext | object | `{}` |  |
| backend.extraEnv | list | `[]` |  |
| backend.waitForDependencies | bool | `false` |  |
| frontend.enabled | bool | `true` |  |
| frontend.replicaCount | int | `1` |  |
| frontend.image.repository | string | `"agentarea/agentarea-frontend"` |  |
| frontend.image.tag | string | `""` |  |
| frontend.image.pullPolicy | string | `""` |  |
| frontend.service.type | string | `"ClusterIP"` |  |
| frontend.service.port | int | `3000` |  |
| frontend.service.annotations | object | `{}` |  |
| frontend.service.labels | object | `{}` |  |
| frontend.livenessProbe.enabled | bool | `true` |  |
| frontend.livenessProbe.initialDelaySeconds | int | `30` |  |
| frontend.livenessProbe.periodSeconds | int | `10` |  |
| frontend.livenessProbe.timeoutSeconds | int | `5` |  |
| frontend.livenessProbe.failureThreshold | int | `3` |  |
| frontend.readinessProbe.enabled | bool | `true` |  |
| frontend.readinessProbe.initialDelaySeconds | int | `15` |  |
| frontend.readinessProbe.periodSeconds | int | `5` |  |
| frontend.readinessProbe.timeoutSeconds | int | `3` |  |
| frontend.readinessProbe.failureThreshold | int | `3` |  |
| frontend.resources | object | `{}` |  |
| frontend.podAnnotations | object | `{}` |  |
| frontend.podLabels | object | `{}` |  |
| frontend.nodeSelector | object | `{}` |  |
| frontend.tolerations | list | `[]` |  |
| frontend.affinity | object | `{}` |  |
| frontend.extraEnv | list | `[]` |  |
| frontend.extraVolumes | list | `[]` |  |
| frontend.extraVolumeMounts | list | `[]` |  |
| frontend.extraContainers | list | `[]` |  |
| worker.enabled | bool | `true` |  |
| worker.replicaCount | int | `1` |  |
| worker.image.repository | string | `"agentarea/agentarea-worker"` |  |
| worker.image.tag | string | `""` |  |
| worker.image.pullPolicy | string | `""` |  |
| worker.healthPort | int | `8081` | Port of the worker's health endpoint, passed to the container as AGENTAREA_WORKER_HEALTH_PORT. /readyz answers 200 once the database, the authorization backend and Redis are reachable and every Temporal worker is polling; /livez answers 200 while the event loop responds. |
| worker.outageWait.retryWindow | string | `"5m"` | How long a call retries before the run starts waiting. |
| worker.outageWait.backoff | string | `"1m,5m,10m"` | Pauses between retries while the run waits, comma-separated. |
| worker.outageWait.deadline | string | `"24h"` | How long a run waits before it fails. |
| worker.skillsWindowShare | string | `"0.3"` | Share of the model's context window all of a run's activated skills may take together (their instructions are never compacted); between 0 and 1. |
| worker.minReadySeconds | int | `10` | Seconds a new pod must stay ready before it counts as available, so a pod that passes readiness and then crashes cannot retire an old replica. |
| worker.shutdownTimeout | int | `120` | Seconds a stopping worker lets in-flight activities (model calls, tools, event writes) finish before it cancels them. A cancelled model call is paid for twice when it reruns on another replica. |
| worker.terminationGracePeriodSeconds | int | `150` | Total budget the kubelet allows the worker before SIGKILL. Keep it above shutdownTimeout, or the drain is cut short. |
| worker.strategy | object | `{"rollingUpdate":{"maxSurge":1,"maxUnavailable":0},"type":"RollingUpdate"}` | Rollout strategy. maxUnavailable 0 keeps every old replica until its replacement is available: a new ReplicaSet that never becomes ready stalls the rollout instead of taking the running workers down. |
| worker.startupProbe | object | `{"enabled":true,"failureThreshold":60,"periodSeconds":5,"timeoutSeconds":3}` | Probes /readyz until the worker first reports ready, holding off the other two probes. periodSeconds x failureThreshold is the startup budget (Temporal connect, OpenFGA bootstrap, database and Redis checks): 5 minutes. |
| worker.readinessProbe | object | `{"enabled":true,"failureThreshold":3,"periodSeconds":10,"timeoutSeconds":3}` | Probes /readyz. The worker serves no traffic, so readiness only gates rollouts: an old replica is retired only for a replacement that is polling. |
| worker.livenessProbe | object | `{"enabled":true,"failureThreshold":6,"periodSeconds":10,"timeoutSeconds":5}` | Probes /livez, answered by the event loop the Temporal workers run on. A loop blocked for about periodSeconds x failureThreshold gets restarted. |
| worker.resources | object | `{}` |  |
| worker.podAnnotations | object | `{}` |  |
| worker.podLabels | object | `{}` |  |
| worker.nodeSelector | object | `{}` |  |
| worker.tolerations | list | `[]` |  |
| worker.affinity | object | `{}` |  |
| worker.extraEnv | list | `[]` |  |
| worker.extraVolumes | list | `[]` |  |
| worker.extraVolumeMounts | list | `[]` |  |
| worker.extraContainers | list | `[]` |  |
| worker.waitForDependencies | bool | `false` |  |
| eventService.enabled | bool | `true` |  |
| eventService.replicaCount | int | `1` |  |
| eventService.image.repository | string | `"agentarea/agentarea-events"` |  |
| eventService.image.tag | string | `""` |  |
| eventService.image.pullPolicy | string | `""` |  |
| eventService.port | int | `8002` |  |
| eventService.pollInterval | string | `"30s"` |  |
| eventService.maxPollers | int | `10` |  |
| eventService.resources | object | `{}` |  |
| eventService.podAnnotations | object | `{}` |  |
| eventService.podLabels | object | `{}` |  |
| eventService.nodeSelector | object | `{}` |  |
| eventService.tolerations | list | `[]` |  |
| eventService.affinity | object | `{}` |  |
| eventService.livenessProbe.enabled | bool | `true` |  |
| eventService.livenessProbe.initialDelaySeconds | int | `30` |  |
| eventService.livenessProbe.periodSeconds | int | `10` |  |
| eventService.livenessProbe.timeoutSeconds | int | `5` |  |
| eventService.livenessProbe.failureThreshold | int | `3` |  |
| eventService.readinessProbe.enabled | bool | `true` |  |
| eventService.readinessProbe.initialDelaySeconds | int | `10` |  |
| eventService.readinessProbe.periodSeconds | int | `5` |  |
| eventService.readinessProbe.timeoutSeconds | int | `3` |  |
| eventService.readinessProbe.failureThreshold | int | `3` |  |
| eventService.extraEnv | list | `[]` |  |
| platformNetworkPolicy.enabled | bool | `false` |  |
| platformNetworkPolicy.blockedEgressCIDRs[0] | string | `"169.254.0.0/16"` |  |
| platformNetworkPolicy.extraEgress | list | `[]` |  |
| mcpManager.enabled | bool | `true` |  |
| mcpManager.replicaCount | int | `1` |  |
| mcpManager.image.repository | string | `"agentarea/agentarea-mcp-manager"` |  |
| mcpManager.image.tag | string | `""` |  |
| mcpManager.service.type | string | `"ClusterIP"` |  |
| mcpManager.service.port | int | `80` |  |
| mcpManager.serviceAccount.create | bool | `true` |  |
| mcpManager.serviceAccount.name | string | `""` |  |
| mcpManager.serviceAccount.annotations | object | `{}` |  |
| mcpManager.tmpVolume.sizeLimit | string | `"1Gi"` |  |
| mcpManager.serverless.enabled | bool | `true` |  |
| mcpManager.serverless.idleTimeout | string | `"10m"` |  |
| mcpManager.serverless.sweepInterval | string | `"60s"` |  |
| mcpManager.serverless.requestLeaseTTL | string | `"90s"` |  |
| mcpManager.serverless.startupTimeout | string | `"5m"` |  |
| mcpManager.mcpBase.image.repository | string | `"agentarea/agentarea-mcp-base"` |  |
| mcpManager.mcpBase.image.tag | string | `""` |  |
| mcpManager.packageImages.repository | string | `""` | Registry repository where immutable images built from npm/PyPI packages are stored. Leave empty to use the local Docker daemon with the Docker backend; Kubernetes and data-plane backends require a repository. |
| mcpManager.packageImages.registrySecret | string | `""` | Existing dockerconfigjson Secret used to authenticate package-image registry lookups and pushes. The Secret is mounted read-only in the manager. |
| mcpManager.packageImages.importTimeout | string | `"15m"` | Maximum time allowed for one package-image import. |
| mcpManager.dataPlane.allowInsecure | bool | `false` |  |
| mcpManager.dataPlane.url | string | `""` |  |
| mcpManager.dataPlane.tokenSecret | string | `""` |  |
| mcpManager.dataPlane.tokenKey | string | `""` |  |
| mcpManager.instanceNetworkPolicy.enabled | bool | `true` |  |
| mcpManager.instanceNetworkPolicy.dnsNamespace | string | `"kube-system"` |  |
| mcpManager.instanceNetworkPolicy.blockedEgressCIDRs[0] | string | `"10.0.0.0/8"` |  |
| mcpManager.instanceNetworkPolicy.blockedEgressCIDRs[1] | string | `"172.16.0.0/12"` |  |
| mcpManager.instanceNetworkPolicy.blockedEgressCIDRs[2] | string | `"192.168.0.0/16"` |  |
| mcpManager.instanceNetworkPolicy.blockedEgressCIDRs[3] | string | `"169.254.0.0/16"` |  |
| mcpManager.instanceNetworkPolicy.probeIngressCIDRs[0] | string | `"10.0.0.0/8"` |  |
| mcpManager.instanceNetworkPolicy.probeIngressCIDRs[1] | string | `"172.16.0.0/12"` |  |
| mcpManager.instanceNetworkPolicy.probeIngressCIDRs[2] | string | `"192.168.0.0/16"` |  |
| mcpManager.instanceNetworkPolicy.extraEgress | list | `[]` |  |
| mcpManager.instanceNetworkPolicy.egressProxy | object | `{}` |  |
| mcpManager.instancePod.labels | object | `{}` |  |
| mcpManager.instancePod.annotations | object | `{}` |  |
| mcpManager.instancePod.nodeSelector | object | `{}` |  |
| mcpManager.instancePod.tolerations | list | `[]` |  |
| mcpManager.instancePod.affinity | object | `{}` |  |
| mcpManager.instancePod.imagePullSecrets | list | `[]` |  |
| mcpManager.instancePod.priorityClassName | string | `""` |  |
| mcpManager.backend | string | `"kubernetes"` |  |
| mcpManager.domain | string | `"mcp.local"` |  |
| mcpManager.gateway.name | string | `"envoy-gateway"` |  |
| mcpManager.gateway.namespace | string | `"envoy-gateway-system"` |  |
| mcpManager.runtimeClass | string | `""` |  |
| mcpManager.isolationTier | string | `"standard"` |  |
| mcpManager.executionCluster.kubeconfigSecret | string | `""` |  |
| mcpManager.executionCluster.kubeconfigKey | string | `""` |  |
| mcpManager.runtime.serviceAccount.create | bool | `true` |  |
| mcpManager.runtime.serviceAccount.name | string | `""` |  |
| mcpManager.runtime.imagePullSecrets | list | `[]` |  |
| mcpManager.securityContext | object | `{}` |  |
| mcpManager.features.enabled[0] | string | `"gateway_api"` |  |
| mcpManager.features.enabled[1] | string | `"state_reconciler"` |  |
| mcpManager.features.enabled[2] | string | `"warm_pool"` |  |
| mcpManager.features.variants | object | `{}` |  |
| mcpManager.warmPool.enabled | bool | `true` |  |
| mcpManager.warmPool.image.repository | string | `"agentarea/agentarea-mcp-runner"` |  |
| mcpManager.warmPool.image.tag | string | `""` |  |
| mcpManager.warmPool.image.pullPolicy | string | `"IfNotPresent"` |  |
| mcpManager.warmPool.idleTimeout | string | `"0s"` |  |
| mcpManager.warmPool.size | int | `1` |  |
| mcpManager.warmPool.logLevel | string | `"info"` |  |
| mcpManager.warmPool.resources.limits.cpu | string | `"500m"` |  |
| mcpManager.warmPool.resources.limits.memory | string | `"512Mi"` |  |
| mcpManager.warmPool.resources.requests.cpu | string | `"100m"` |  |
| mcpManager.warmPool.resources.requests.memory | string | `"256Mi"` |  |
| mcpManager.resources | object | `{}` |  |
| mcpManager.extraEnv | list | `[]` |  |
| sandboxRuntime.provider | string | `""` |  |
| sandboxRuntime.region | string | `""` |  |
| sandboxRuntime.runtimeClass | string | `"gvisor"` |  |
| sandboxRuntime.allowWeakIsolationForDevelopment | bool | `false` |  |
| sandboxRuntime.allowInternet | bool | `false` |  |
| sandboxRuntime.leaseTTL | string | `"2h"` |  |
| sandboxRuntime.provisioningTimeout | string | `"30s"` |  |
| sandboxRuntime.idleTTL | string | `"15m"` |  |
| sandboxRuntime.sessionRecordTTL | string | `"24h"` |  |
| sandboxRuntime.executionRecordTTL | string | `"24h"` |  |
| sandboxRuntime.maxExecutionTimeoutSeconds | int | `1800` |  |
| sandboxRuntime.defaultExecutionTimeoutSeconds | int | `120` |  |
| sandboxRuntime.executionQueueTimeout | string | `"5m"` |  |
| sandboxRuntime.executionCompletionGrace | string | `"2m"` |  |
| sandboxRuntime.workspace.maxFiles | string | `"10000"` |  |
| sandboxRuntime.workspace.maxFileBytes | string | `"268435456"` |  |
| sandboxRuntime.workspace.maxBytes | string | `"2147483648"` |  |
| sandboxRuntime.workspace.signedUrlTTL | string | `"1h"` |  |
| sandboxRuntime.workspace.forcePathStyle | bool | `true` |  |
| sandboxRuntime.resources.cpu | string | `"500m"` |  |
| sandboxRuntime.resources.memory | string | `"512Mi"` |  |
| sandboxRuntime.resources.cpuRequest | string | `""` | What the scheduler reserves per sandbox, when the provider schedules on Kubernetes (OpenSandbox's Kubernetes runtime). Empty reserves the full limit, which leaves a small node room for only a few sandboxes. |
| sandboxRuntime.resources.memoryRequest | string | `""` | Memory reserved per sandbox; see cpuRequest. |
| sandboxRuntime.resources.storageLimit | string | `""` | A sandbox's ephemeral-storage limit on Kubernetes providers. It covers the workspace plus the container's own writes and is enforced by eviction. Empty is the workspace quota (workspace.maxBytes) plus 1Gi. |
| sandboxRuntime.resources.storageRequest | string | `""` | Ephemeral storage reserved per sandbox. Empty reserves the full limit. |
| sandboxRuntime.manifest | object | `{}` |  |
| sandboxRuntime.opensandbox.url | string | `""` |  |
| sandboxRuntime.opensandbox.allowInsecure | bool | `false` |  |
| sandboxRuntime.opensandbox.secureAccess | bool | `true` |  |
| sandboxRuntime.opensandbox.isolation | string | `""` |  |
| sandboxRuntime.opensandbox.runtimeIdentity | string | `""` |  |
| sandboxRuntime.opensandbox.egressMode | string | `""` |  |
| sandboxRuntime.opensandbox.allowWeakIsolationForDevelopment | bool | `false` |  |
| sandboxRuntime.opensandbox.useServerProxy | bool | `true` |  |
| sandboxRuntime.opensandbox.authHeader | string | `"OPEN-SANDBOX-API-KEY"` |  |
| sandboxRuntime.opensandbox.apiKeySecretRef.name | string | `""` |  |
| sandboxRuntime.opensandbox.apiKeySecretRef.key | string | `""` |  |
| sandboxRuntime.opensandbox.image | string | `""` |  |
| sandboxRuntime.opensandbox.entrypoint | list | `[]` |  |
| sandboxRuntime.e2b.apiUrl | string | `""` |  |
| sandboxRuntime.e2b.sandboxUrl | string | `""` |  |
| sandboxRuntime.e2b.allowInsecure | bool | `false` |  |
| sandboxRuntime.e2b.isolation | string | `"firecracker"` |  |
| sandboxRuntime.e2b.attestationPath | string | `"/etc/agentarea/isolation-attestation.json"` |  |
| sandboxRuntime.e2b.runtimeIdentity | string | `""` |  |
| sandboxRuntime.e2b.apiKeySecretRef.name | string | `""` |  |
| sandboxRuntime.e2b.apiKeySecretRef.key | string | `""` |  |
| sandboxRuntime.e2b.template | string | `""` |  |
| sandboxRuntime.cube.apiUrl | string | `""` |  |
| sandboxRuntime.cube.sandboxUrl | string | `""` |  |
| sandboxRuntime.cube.allowInsecure | bool | `false` |  |
| sandboxRuntime.cube.isolation | string | `"firecracker"` |  |
| sandboxRuntime.cube.attestationPath | string | `"/etc/agentarea/isolation-attestation.json"` |  |
| sandboxRuntime.cube.runtimeIdentity | string | `""` |  |
| sandboxRuntime.cube.apiKeySecretRef.name | string | `""` |  |
| sandboxRuntime.cube.apiKeySecretRef.key | string | `""` |  |
| sandboxRuntime.cube.template | string | `""` |  |
| mcpSandboxRunner.enabled | bool | `true` |  |
| mcpSandboxRunner.replicaCount | int | `1` |  |
| mcpSandboxRunner.image.repository | string | `""` |  |
| mcpSandboxRunner.image.tag | string | `""` |  |
| mcpSandboxRunner.serviceAccount.create | bool | `true` |  |
| mcpSandboxRunner.serviceAccount.name | string | `""` |  |
| mcpSandboxRunner.serviceAccount.annotations | object | `{}` |  |
| mcpSandboxRunner.tmpVolume.sizeLimit | string | `"512Mi"` |  |
| mcpSandboxRunner.consumerGroup | string | `"agentarea-sandbox-runners"` |  |
| mcpSandboxRunner.batchSize | int | `1` |  |
| mcpSandboxRunner.resources.requests.cpu | string | `"50m"` |  |
| mcpSandboxRunner.resources.requests.memory | string | `"96Mi"` |  |
| mcpSandboxRunner.resources.limits.cpu | string | `"500m"` |  |
| mcpSandboxRunner.resources.limits.memory | string | `"512Mi"` |  |
| mcpSandboxRunner.extraEnv | list | `[]` |  |
| temporal.enabled | bool | `true` |  |
| temporal.replicaCount | int | `1` |  |
| temporal.image.repository | string | `"temporalio/server"` |  |
| temporal.image.tag | string | `"1.32.1"` |  |
| temporal.adminTools.image.repository | string | `"temporalio/admin-tools"` |  |
| temporal.adminTools.image.tag | string | `"1.32.1"` |  |
| temporal.namespaceRetention | string | `"24h"` |  |
| temporal.database.name | string | `"temporal"` |  |
| temporal.service.type | string | `"ClusterIP"` |  |
| temporal.service.port | int | `7233` |  |
| temporal.resources | object | `{}` |  |
| temporal.extraEnv | list | `[]` |  |
| postgresql.enabled | bool | `true` |  |
| postgresql.image.repository | string | `"postgres"` |  |
| postgresql.image.tag | string | `"16.15-alpine"` |  |
| postgresql.resources.limits.cpu | string | `"500m"` |  |
| postgresql.resources.limits.memory | string | `"512Mi"` |  |
| postgresql.resources.requests.cpu | string | `"250m"` |  |
| postgresql.resources.requests.memory | string | `"256Mi"` |  |
| postgresql.persistence.enabled | bool | `true` |  |
| postgresql.persistence.size | string | `"8Gi"` |  |
| postgresql.persistence.storageClass | string | `""` |  |
| redis.enabled | bool | `true` |  |
| valkey.auth.enabled | bool | `true` |  |
| valkey.auth.usersExistingSecret | string | `"agentarea-redis-secret"` |  |
| valkey.auth.aclUsers.default.permissions | string | `"~* &* +@all"` |  |
| valkey.auth.aclUsers.default.passwordKey | string | `"redis-password"` |  |
| valkey.replica.enabled | bool | `false` |  |
| valkey.deploymentStrategy | string | `"Recreate"` |  |
| valkey.dataStorage.enabled | bool | `true` |  |
| valkey.dataStorage.requestedSize | string | `"4Gi"` |  |
| valkey.dataStorage.className | string | `""` |  |
| valkey.valkeyConfig | string | `"appendonly yes\nappendfsync everysec\nmaxmemory 768mb\nmaxmemory-policy noeviction\n"` |  |
| valkey.resources.limits.cpu | string | `"500m"` |  |
| valkey.resources.limits.memory | string | `"1Gi"` |  |
| valkey.resources.requests.cpu | string | `"100m"` |  |
| valkey.resources.requests.memory | string | `"1Gi"` |  |
| rustfs.enabled | bool | `true` |  |
| rustfs.image.repository | string | `"rustfs/rustfs"` |  |
| rustfs.image.tag | string | `"1.0.3"` |  |
| rustfs.auth.existingSecret | string | `"agentarea-rustfs-secret"` |  |
| rustfs.defaultBuckets | string | `""` |  |
| rustfs.resources.limits.cpu | string | `"500m"` |  |
| rustfs.resources.limits.memory | string | `"512Mi"` |  |
| rustfs.resources.requests.cpu | string | `"250m"` |  |
| rustfs.resources.requests.memory | string | `"256Mi"` |  |
| rustfs.persistence.enabled | bool | `true` |  |
| rustfs.persistence.size | string | `"10Gi"` |  |
| rustfs.readinessProbe.tcpSocket.port | string | `"rustfs"` |  |
| rustfs.readinessProbe.initialDelaySeconds | int | `10` |  |
| rustfs.readinessProbe.periodSeconds | int | `10` |  |
| rustfs.readinessProbe.timeoutSeconds | int | `5` |  |
| rustfs.readinessProbe.failureThreshold | int | `6` |  |
| rustfs.livenessProbe.tcpSocket.port | string | `"rustfs"` |  |
| rustfs.livenessProbe.initialDelaySeconds | int | `20` |  |
| rustfs.livenessProbe.periodSeconds | int | `20` |  |
| rustfs.livenessProbe.timeoutSeconds | int | `5` |  |
| rustfs.livenessProbe.failureThreshold | int | `6` |  |
| jobs.dbMigration.enabled | bool | `true` |  |
| registryReconcile.enabled | bool | `true` |  |
| registryReconcile.workspaceRegistries | bool | `false` | Also sync every active registry a workspace admin added (`--workspace-registries`). A tenant's failing source is recorded on its registry and does not fail the Job. |
| registryReconcile.registries[0].name | string | `"system-llm-providers"` |  |
| registryReconcile.registries[0].source_url | string | `"https://agentarea-mcp-registry.s3.amazonaws.com/registry/system/llm-providers.json"` |  |
| registryReconcile.registries[0].recommendation_priority | int | `10` |  |
| registryReconcile.registries[1].name | string | `"system-llm-models"` |  |
| registryReconcile.registries[1].source_url | string | `"https://agentarea-mcp-registry.s3.amazonaws.com/registry/system/llm-models.json"` |  |
| registryReconcile.registries[1].recommendation_priority | int | `10` |  |
| registryReconcile.registries[2].name | string | `"system-mcp-servers"` |  |
| registryReconcile.registries[2].source_url | string | `"https://agentarea-mcp-registry.s3.amazonaws.com/registry/system/mcp-servers.json"` |  |
| registryReconcile.registries[2].recommendation_priority | int | `10` |  |
| registryReconcile.registries[3].name | string | `"system-skills-curated"` |  |
| registryReconcile.registries[3].source_url | string | `"https://agentarea-mcp-registry.s3.amazonaws.com/registry/system/skills-curated.json"` |  |
| registryReconcile.registries[3].recommendation_priority | int | `10` |  |
| registryReconcile.registries[4].name | string | `"system-agents"` |  |
| registryReconcile.registries[4].source_url | string | `"https://agentarea-mcp-registry.s3.amazonaws.com/registry/system/agents.json"` |  |
| registryReconcile.registries[4].recommendation_priority | int | `10` |  |
| registryReconcile.registries[5].name | string | `"system-source-types"` |  |
| registryReconcile.registries[5].source_url | string | `"https://agentarea-mcp-registry.s3.amazonaws.com/registry/system/source-types.json"` |  |
| registryReconcile.registries[5].recommendation_priority | int | `10` |  |
| openfga.enabled | bool | `true` |  |
| openfga.replicaCount | int | `1` |  |
| openfga.image.repository | string | `"openfga/openfga"` |  |
| openfga.image.tag | string | `"v1.22.0"` |  |
| openfga.database.name | string | `"openfga"` |  |
| openfga.database.createJob.enabled | bool | `true` |  |
| openfga.log.level | string | `"info"` |  |
| openfga.log.format | string | `"json"` |  |
| openfga.service.httpPort | int | `8080` |  |
| openfga.service.grpcPort | int | `8081` |  |
| openfga.service.metricsPort | int | `2112` |  |
| openfga.service.playgroundPort | int | `3000` |  |
| openfga.playground.enabled | bool | `false` |  |
| openfga.accessControl.storeId | string | `""` |  |
| openfga.accessControl.authorizationModelId | string | `""` |  |
| openfga.accessControl.storeName | string | `"agentarea"` |  |
| openfga.accessControl.autoBootstrap | bool | `true` |  |
| openfga.accessControl.autoApplyModel | bool | `true` |  |
| kratos.enabled | bool | `true` |  |
| kratos.replicaCount | int | `1` |  |
| kratos.image.repository | string | `"oryd/kratos"` |  |
| kratos.image.tag | string | `"v26.2.0"` |  |
| kratos.urls.public | string | `""` |  |
| kratos.urls.publicBrowser | string | `""` |  |
| kratos.urls.admin | string | `""` |  |
| kratos.database.name | string | `"kratos"` |  |
| kratos.database.createJob.enabled | bool | `true` |  |
| kratos.configMapOverrideName | string | `""` |  |
| kratos.files | object | `{}` |  |
| kratos.secretName | string | `""` |  |
| kratos.generateJwks | bool | `true` |  |
| kratos.runtimeSecretName | string | `""` |  |
| kratos.smtp.connection_uri | string | `""` |  |
| kratos.smtp.from_address | string | `"noreply@example.com"` |  |
| kratos.smtp.from_name | string | `"AgentArea"` |  |
| kratos.session.cookieDomain | string | `"localhost"` |  |
| kratos.jwt.kid | string | `"agentarea-jwt-key-1"` |  |
| kratos.jwt.jwks_b64 | string | `""` |  |
| kratos.jwt.jwks_public_b64 | string | `""` |  |
| kratos.jwt.claims_mapper_b64 | string | `""` |  |
| kratos.jwt.issuer | string | `"https://agentarea.dev"` |  |
| kratos.jwt.audience | string | `"agentarea-api"` |  |
| kratos.identitySchema | string | `"{\n  \"$id\": \"https://schemas.ory.sh/presets/kratos/quickstart/email-password/identity.schema.json\",\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"title\": \"Person\",\n  \"type\": \"object\",\n  \"properties\": {\n    \"traits\": {\n      \"type\": \"object\",\n      \"properties\": {\n        \"email\": {\n          \"type\": \"string\",\n          \"format\": \"email\",\n          \"title\": \"Email\",\n          \"ory.sh/kratos\": {\n            \"credentials\": {\n              \"password\": {\n                \"identifier\": true\n              }\n            },\n            \"recovery\": {\n              \"via\": \"email\"\n            }\n          }\n        },\n        \"name\": {\n          \"type\": \"object\",\n          \"properties\": {\n            \"first\": {\n              \"title\": \"First Name\",\n              \"type\": \"string\"\n            },\n            \"last\": {\n              \"title\": \"Last Name\",\n              \"type\": \"string\"\n            }\n          }\n        },\n        \"username\": {\n          \"type\": \"string\",\n          \"title\": \"Username\"\n        }\n      },\n      \"required\": [\n        \"email\"\n      ],\n      \"additionalProperties\": false\n    }\n  }\n}\n"` |  |
| kratos.config.version | string | `"v26.2.0"` |  |
| kratos.config.serve.public.cors.enabled | bool | `true` |  |
| kratos.config.serve.public.cors.allowed_origins[0] | string | `"https://staging-0.agentarea.ai"` |  |
| kratos.config.serve.public.cors.allowed_origins[1] | string | `"https://*.staging-0.agentarea.ai"` |  |
| kratos.config.serve.public.cors.allowed_methods[0] | string | `"POST"` |  |
| kratos.config.serve.public.cors.allowed_methods[1] | string | `"GET"` |  |
| kratos.config.serve.public.cors.allowed_methods[2] | string | `"PUT"` |  |
| kratos.config.serve.public.cors.allowed_methods[3] | string | `"PATCH"` |  |
| kratos.config.serve.public.cors.allowed_methods[4] | string | `"DELETE"` |  |
| kratos.config.serve.public.cors.allowed_headers[0] | string | `"Authorization"` |  |
| kratos.config.serve.public.cors.allowed_headers[1] | string | `"Cookie"` |  |
| kratos.config.serve.public.cors.allowed_headers[2] | string | `"Content-Type"` |  |
| kratos.config.serve.public.cors.allowed_headers[3] | string | `"X-Session-Token"` |  |
| kratos.config.serve.public.cors.exposed_headers[0] | string | `"Content-Type"` |  |
| kratos.config.serve.public.cors.exposed_headers[1] | string | `"Set-Cookie"` |  |
| kratos.config.secrets.cookie[0] | string | `"${KRATOS_SECRETS_COOKIE}"` |  |
| kratos.config.secrets.cipher[0] | string | `"${KRATOS_SECRETS_CIPHER}"` |  |
| kratos.config.ciphers.algorithm | string | `"xchacha20-poly1305"` |  |
| kratos.config.hashers.algorithm | string | `"bcrypt"` |  |
| kratos.config.hashers.bcrypt.cost | int | `12` |  |
| kratos.config.identity.default_schema_id | string | `"default"` |  |
| kratos.config.identity.schemas[0].id | string | `"default"` |  |
| kratos.config.identity.schemas[0].url | string | `"file:///etc/config/kratos/identity.schema.json"` |  |

## Secrets

For production, create required secrets ahead of time and reference them via `global.secrets.*`:

```bash
kubectl create secret generic agentarea-postgresql-secret \
  --from-literal=username=postgres \
  --from-literal=password=<password> \
  --from-literal=postgres-password=<password>

kubectl create secret generic agentarea-redis-secret \
  --from-literal=redis-password=<password>

kubectl create secret generic agentarea-rustfs-secret \
  --from-literal=root-user=<access-key> \
  --from-literal=root-password=<secret-key>
```

## Upgrade

```bash
helm upgrade agentarea agentarea/agentarea -f values.yaml
```
